package com.eelection

data class CandidatesDataClass(var Username:String="", var UserImg:String="", var Designation:String="",var Party_Name:String="",var Constituency:String="",
                               var User_Info:String="",var CandidateNumber:String=""
)