package com.eelection

data class CampaignDataClass(var Party_Name:String, var Video_URL:String, var Image:String, var Type:String,
                             var Title:String,
                             var CampaignNumber:String,
                             var Time:String)