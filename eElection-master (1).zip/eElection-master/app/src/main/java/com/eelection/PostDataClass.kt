package com.eelection

data class PostDataClass(var Username:String="", var UserImg:String="", var Designation:String="",var Party_Name:String="",
                         var Video_Url:String="", var Image:String="", var Type:String="", var PostText:String="",
                             var Likes:String="", var Comments:String="",
                             var PostNumber:String="", var UserLike:String=""
                             )